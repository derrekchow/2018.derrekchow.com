import React from 'react'
import Link from 'gatsby-link'
import Helmet from 'react-helmet'
import Column from '../components/column'
import ListItem from '../components/listitem'
import Category from '../components/category'

import {FaLinkedin, FaPaperPlane, FaTrophy, FaGithub} from 'react-icons/lib/fa'

import '../styles/index.css'

const Intro = () => (
  <div align="center" style={{ 
    margin:'auto',
    fontSize:'1.7em',
    lineHeight:1.5,
    maxWidth: '25em',
    marginTop: '6rem',
    paddingBottom: '2em',

  }}>
    I'm <b>Derrek Chow</b>, a software developer and student currently studying Software Engineering at the University of Waterloo.
    <br/>
    <div style={{
      fontSize: '.7em',
      fontWeight: 500,
      margin: '1em',
    }}>
    <a href="../static/DerrekChowResume.pdf" target="_blank" >Check out my resume</a><br/>
    </div>
    <a className="icon" href="https://github.com/derrekchow" target="_blank"><FaGithub/></a>
    <a className="icon" href="https://www.linkedin.com/in/derrekchow/" target="_blank"><FaLinkedin/></a>
    <a className="icon" href="mailto:me@derrekchow.com"><FaPaperPlane/></a>
  </div>
)

const Main = (props) => (
  <div className="main" style={{
    display: 'flex',
    margin: 'auto',
    textAlign: 'left',
    justifyContent: 'space-between',
    maxWidth: '50em',
    flexWrap: 'wrap',
  }}>
  {props.children}
  </div>
)

export default () => (
  <div style={{
    letterSpacing: '1px',
    lineHeight: 1.8,
    fontSize: '0.9em',
    margin: '0 1em',
    textAlign: 'center',
  }}>
    <Helmet
          title='Derrek Chow'
          meta={[
            { name: 'description', content: 'Software Engineering student at the University of Waterloo.' },
            { name: 'keywords', content: 'software, engineer, waterloo, student' },
            { name: 'viewport', content: 'width=device-width' }
          ]}
    />
    <Intro />
    <hr style={{
      maxWidth: '40em',
      margin: 'auto',
      marginBottom: '3em',
      opacity: .2,
    }}/>
    <Main>
      <Column>
        <Category title="EXPERIENCE">
          <ListItem link="http://fellowship.myplanet.com/" title="Myplanet" desc="Fellow"/>
          <ListItem link="https://viceroymedia.net" title="Viceroy Media Inc." desc="Software Developer Intern"/>
        </Category>
        <Category title="WORK">
          <ListItem link="http://uog.viceroymedia.net/" title="UoG Exam Network" desc="Platform for students to upload exam material and professor/course reviews." star="true"/>
          <ListItem link="https://github.com/AmnonSkladman/MyPlanet_Pathways" title="Excel Sheets Parser" desc="Organizes and presents data from excel sheets for Pathways Canada." />
          <ListItem link="https://econonet.net/" title="econoNet" desc="Econonet" desc="Provides businesses with web hosting essentials which can be managed from a mobile app."/>
        </Category>
      </Column>
      <Column>
        <Category title="PROJECTS">
          <ListItem link="https://github.com/edwinzhng/automatic-cannon" title="Automatic Cannon" desc="Spring-loaded mini cannon, tracks and fires at target using facial recognition." star="true"/>
          <ListItem link="http://18.221.15.32" title="wohWiki" desc="Combines a wikiHow article and picture with a random step." star="true"/>
          <ListItem link="http://wikinotes.000webhostapp.com/" title="wikiNotes" desc="Platform for student uploaded study notes." trophy="true"/>
          <ListItem link="http://iroquoisridge.github.io/ridgeclubs/" title="Ridge Clubs" desc="Website for the clubs at Iroquois Ridge High School."/>
          <ListItem link="http://iroquoisridge.github.io/ridgehacks/" title="Ridge Hacks" desc="Website for Ridge Hacks hackathon."/>
        </Category>
      </Column>
      <Column>
        <Category title="HACAKTHONS">
          <ListItem link="https://devpost.com/software/hungr-ai" title="HackWestern IV" desc="Hungr.ai" date="Nov. 2017" trophy="true"/>
          <ListItem link="https://devpost.com/software/hack-the-fridge" title="Hack the North" desc="Hack the Fridge" date="Sept. 2017"/>
          <ListItem link="https://devpost.com/software/point-to-speech-rvsa0y" title="MasseyHacks III" desc="Point 2 Speech" date="Apr. 2017" trophy="true"/>
          <ListItem link="https://devpost.com/software/my-maestro" title="Hack Western III" desc="Pinch Perfect" date="Oct. 2016"/>
          <ListItem link="https://devpost.com/software/3-to-1-time-manager" title="MasseyHacks II" desc="3to1 Timer" date="Apr. 2016"/>
          <a id="hack" href="https://iroquoisridge.github.io/ridgehacks/" target="_blank">I also ran my own <br/>hackathon at my<br/> school</a>
        </Category>
      </Column>
    </Main><br/>
    <footer style={{opacity:.3}} >
      © 2018 Derrek Chow<br/>
      Made with love (and React)
    </footer>
    <br/>
  </div>
)