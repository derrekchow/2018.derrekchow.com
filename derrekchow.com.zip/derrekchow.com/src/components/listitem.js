import React from "react"
import '../styles/index.css'

import {FaTrophy, FaStar} from 'react-icons/lib/fa'


class ListItem extends React.Component {
  render() {
    return (
      <div>
      	<a style={{paddingBottom: '2px'}} href={this.props.link} target="_blank">{this.props.title}</a>&nbsp;
        {this.props.trophy ? <FaTrophy/> : null}{this.props.star ? <FaStar/> : null}
        <p style={{fontSize: '0.9em', margin: '.3em 0',}}>
          {this.props.desc ? this.props.desc : null}
          {this.props.date ? <span> &middot; </span> : null}
          {this.props.date ? this.props.date : null}
      	</p>
        <br/>
      	{this.props.children}
      </div>
    )
  }
}

export default ListItem