import React from "react"

class Category extends React.Component {
  render() {
    return (
      <div style={{paddingBottom:'.5rem'}}>
      	<h1 style={{
      		fontSize: '.8em',
      		opacity: '.4',
      		fontFamily: 'Quicksand',
          letterSpacing: '2px',
      		paddingBottom: '1em',
      	}}>{this.props.title}</h1>
      	{this.props.children}
      </div>
    )
  }
}

export default Category